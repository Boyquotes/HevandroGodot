using Godot;
using System;

public partial class Coins : Area2D
{
	private AnimatedSprite2D animacao;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		animacao = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
		animacao.Play("idle");
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
	}

	private void _on_body_entered(Node2D body)
	{
		if (body is jogador)
		{
			GD.Print("Moeda Coletada!");
			main.IncrementCoinCount(); // Incrementa o contador de moedas
			GD.Print(main.GetCoinCount());
			if (main.GetCoinCount() == 3) // Verifica se o jogador coletou três moedas
				{
					GD.Print("Mapa concluido com sucesso!");
				}
			QueueFree();
		}
	}
}
